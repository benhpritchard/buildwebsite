import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | noauth | forbidden
  const [note, setNote] = useState("");

  useEffect(() => {
    // 1) INSTANT fallback: if user is already logged in and we have a cached role, don't block.
    const cachedRole = localStorage.getItem("finnquest_role");
    const alreadyLoggedIn = !!auth.currentUser;

    if (alreadyLoggedIn && cachedRole && allow.includes(cachedRole)) {
      setNote("Using cached role (Firestore blocked).");
      setStatus("ok");
    }

    // 2) Always listen to auth, and try Firestore when possible (but NEVER block forever)
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setStatus("noauth");
        return;
      }

      // If we can read Firestore, great — update role
      try {
        const profile = await getTeacherProfile(user.uid);
        const role = profile?.role || "teacher";
        localStorage.setItem("finnquest_role", role);

        if (allow.includes(role)) setStatus("ok");
        else setStatus("forbidden");
      } catch (e) {
        // Firestore blocked/unavailable: fallback to cached role, or default teacher
        const role = localStorage.getItem("finnquest_role") || "teacher";
        localStorage.setItem("finnquest_role", role);

        if (allow.includes(role)) {
          setNote("Firestore blocked — using cached role.");
          setStatus("ok");
        } else {
          setStatus("forbidden");
        }
      }
    });

    return () => unsub();
  }, [allow]);

  if (status === "loading") {
    return (
      <div className="pt-32 text-center">
        <div className="font-semibold">Loading…</div>
        <div className="text-xs opacity-70 mt-2">{note || "Checking access…"}</div>
      </div>
    );
  }

  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;

  return (
    <>
      {/* optional small note while you test */}
      {note ? (
        <div className="pt-24 text-center text-xs opacity-60">
          {note}
        </div>
      ) : null}
      {children}
    </>
  );
}
