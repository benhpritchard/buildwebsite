import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { LogOut, Gamepad2, User, Building2, Brain } from 'lucide-react';
import Header from '../components/finquest/Header';
import Footer from '../components/finquest/Footer';
import { 
  DEFAULT_BASE_IMAGE,
  HAIR_OPTIONS,
  AVATAR_OPTIONS,
  OUTFITS_OPTIONS,
  TRANSPORT_OPTIONS,
  BACKGROUND_OPTIONS,
  AVATAR_BACKGROUND_DEFAULT,
} from '../components/avatar/avatarData';

export default function StudentDashboard() {
  const [student, setStudent] = useState(null);

  useEffect(() => {
    const storedStudent = localStorage.getItem('finnquest_student') || localStorage.getItem('finquest_student');
    if (!storedStudent) {
      window.location.href = createPageUrl('StudentLogin');
      return;
    }
    setStudent(JSON.parse(storedStudent));
  }, []);

  // Fetch teacher data to check unlocked years
  const { data: teacherData } = useQuery({
    queryKey: ['teacher', student?.teacher_id],
    queryFn: async () => {
      const teachers = await base44.entities.Teacher.filter({ id: student.teacher_id });
      return teachers[0];
    },
    enabled: !!student?.teacher_id,
  });

  // Fetch class data
  const { data: classData } = useQuery({
    queryKey: ['class', student?.class_id],
    queryFn: async () => {
      const classes = await base44.entities.Class.filter({ id: student.class_id });
      return classes[0];
    },
    enabled: !!student?.class_id,
  });

  const handleLogout = () => {
    localStorage.removeItem('finnquest_student');
    window.location.href = createPageUrl('Home');
  };

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FAF7F0' }}>
        <p>Loading...</p>
      </div>
    );
  }

  const avatarState = student.avatar_state;
  const points = avatarState?.points || 100;

  // Get avatar customization details
  const selectedHair = HAIR_OPTIONS.find(h => h.id === avatarState?.avatar?.hair);
  const selectedAvatar = AVATAR_OPTIONS.find(a => a.id === avatarState?.avatar?.avatar) || AVATAR_OPTIONS[0];
  const selectedOutfit = OUTFITS_OPTIONS.find(o => o.id === avatarState?.avatar?.outfits);
  const selectedTransport = TRANSPORT_OPTIONS.find(t => t.id === avatarState?.avatar?.transport);
  const selectedBackground = BACKGROUND_OPTIONS.find(b => b.id === avatarState?.avatar?.background) || BACKGROUND_OPTIONS[0];
  const playerName = avatarState?.playerDetails?.name || student.name;

  // Resolve avatar image (outfit vs base)
  const hasOutfit = selectedOutfit?.image || selectedOutfit?.avatarImages;
  const getOutfitImage = () => {
    if (!selectedOutfit) return null;
    if (selectedOutfit.avatarImages && avatarState.avatar?.avatar) {
      return selectedOutfit.avatarImages[avatarState.avatar.avatar] || selectedOutfit.image;
    }
    return selectedOutfit.image;
  };
  const avatarImage = hasOutfit ? getOutfitImage() : (selectedAvatar?.image || DEFAULT_BASE_IMAGE);

  // Positions
  const basePosition = avatarState?.avatar?.layerPositions?.base || { x: 0, y: 0, scale: 1 };
  const hairPosition = avatarState?.avatar?.layerPositions?.hair || { x: 0, y: 0, scale: 1 };
  const transportPosition = avatarState?.avatar?.layerPositions?.transport || { x: 0, y: 0, scale: 1 };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAF7F0' }}>
      <Header />
      
      <div className="pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex justify-between items-start mb-8">
            <div className="flex items-center gap-6">
              {/* Mini Avatar with customization */}
              <div 
                className="w-24 h-24 rounded-xl overflow-hidden border-2 border-blue-900 relative"
                style={{ 
                  backgroundImage: `url(${selectedBackground?.image || AVATAR_BACKGROUND_DEFAULT})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
              >
                 {/* Scaled down version of the main avatar preview */}
                 <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
                    <div style={{ transform: 'scale(0.35)', transformOrigin: 'center center', width: '240px', height: '240px', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        {/* Base Avatar Container */}
                        <div 
                          style={{
                            width: '240px',
                            height: '240px',
                            transform: `translate(${basePosition.x}px, ${basePosition.y}px) scale(${basePosition.scale})`,
                            position: 'relative',
                            display: 'flex',
                            alignItems: 'flex-end',
                            justifyContent: 'center',
                            marginLeft: '-40px', // Match the shift in the editor
                          }}
                        >
                          <img 
                            src={avatarImage} 
                            alt="Avatar" 
                            className="h-full w-auto object-contain"
                          />
                          {selectedHair?.image && (
                            <img 
                              src={selectedHair.image} 
                              alt="Hair"
                              className="absolute object-contain"
                              style={{ 
                                zIndex: 10,
                                left: `calc(50% + ${hairPosition.x}px)`,
                                top: `${hairPosition.y}px`,
                                transform: `translateX(-50%) scale(${hairPosition.scale})`,
                                width: '60px',
                              }}
                            />
                          )}
                        </div>

                        {/* Transport Layer */}
                        {selectedTransport?.image && (
                          <div
                            className="absolute object-contain"
                            style={{ 
                              zIndex: 5,
                              right: '20px',
                              bottom: '10px',
                              width: '100px',
                              transform: `translate(${transportPosition.x}px, ${transportPosition.y}px) scale(${transportPosition.scale})`,
                            }}
                          >
                            <img 
                              src={selectedTransport.image} 
                              alt="Transport"
                              className="w-full h-full object-contain"
                            />
                          </div>
                        )}
                    </div>
                 </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold" style={{ color: '#3448C5' }}>Welcome, {playerName}!</h1>
                <p className="text-gray-600">{classData?.name} • {classData?.year_group}</p>
                <div className="mt-1 inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-bold" style={{ backgroundColor: '#f6a623', color: '#2b1600' }}>
                  {points} pts
                </div>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" /> Logout
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1. Play Games */}
            <Link to={createPageUrl('ExploreGames')}>
              <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center h-full">
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: '#3448C5' }}
                  >
                    <Gamepad2 className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2" style={{ color: '#3448C5' }}>Play Games</h2>
                  <p className="text-gray-600">Explore financial literacy games</p>
                </CardContent>
              </Card>
            </Link>

            {/* 2. Avatar */}
            <Link to={createPageUrl('AvatarCreation')}>
              <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center h-full">
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: '#35D0BA' }}
                  >
                    <User className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2" style={{ color: '#3448C5' }}>My Avatar</h2>
                  <p className="text-gray-600">Customize your character</p>
                </CardContent>
              </Card>
            </Link>

            {/* 3. Office */}
            <Link to={createPageUrl('AvatarCreation')}>
              <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center h-full">
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: '#f6a623' }}
                  >
                    <Building2 className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2" style={{ color: '#3448C5' }}>My Office</h2>
                  <p className="text-gray-600">Design your workspace</p>
                </CardContent>
              </Card>
            </Link>

            {/* 4. Take Quiz */}
            <Link to={createPageUrl('TakeQuiz')}>
              <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center h-full">
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: '#ec4899' }}
                  >
                    <Brain className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2" style={{ color: '#3448C5' }}>Take Quiz</h2>
                  <p className="text-gray-600">Test your knowledge</p>
                </CardContent>
              </Card>
            </Link>
          </div>

          {/* Unlocked Content Info */}
          {teacherData?.unlocked_years?.length > 0 && (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Your Unlocked Content</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {teacherData.unlocked_years.map((year) => (
                    <span 
                      key={year}
                      className="px-4 py-2 rounded-full text-white font-medium"
                      style={{ backgroundColor: '#35D0BA' }}
                    >
                      {year}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}