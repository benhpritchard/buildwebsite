import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | noauth | forbidden
  const [note, setNote] = useState("");

  useEffect(() => {
    // 1) Immediate local fallback (never block)
    const cachedRole = localStorage.getItem("finnquest_role") || "teacher";

    // If we have ANY cached role and it’s allowed, render immediately.
    if (allow.includes(cachedRole)) {
      setNote("Access granted (cached role).");
      setStatus("ok");
    } else {
      // don’t decide forbidden yet — Firebase auth may confirm a better role
      setNote("Checking login…");
      setStatus("loading");
    }

    // 2) Confirm Firebase Auth (fast)
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setStatus("noauth");
        return;
      }

      // 3) Try Firestore role (non-blocking upgrade)
      try {
        const profile = await getTeacherProfile(user.uid);
        const role = profile?.role || "teacher";
        localStorage.setItem("finnquest_role", role);

        if (allow.includes(role)) {
          setNote("");
          setStatus("ok");
        } else {
          setStatus("forbidden");
        }
      } catch (e) {
        // Firestore is blocked/offline — DO NOT BLOCK APP
        const role = localStorage.getItem("finnquest_role") || "teacher";
        if (allow.includes(role)) {
          setNote("Firestore blocked — using cached access.");
          setStatus("ok");
        } else {
          // if no cached role allows it, fall back to teacher access for now
          // (prevents lockout during network issues)
          setNote("Firestore blocked — allowing temporary access.");
          setStatus("ok");
        }
      }
    });

    // Safety: if auth takes too long, still allow the app to load
    const t = setTimeout(() => {
      if (status === "loading") {
        setNote("Slow network — allowing access.");
        setStatus("ok");
      }
    }, 2500);

    return () => {
      clearTimeout(t);
      unsub();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (status === "loading") {
    return (
      <div className="pt-32 text-center">
        <div className="font-semibold">Loading…</div>
        <div className="text-xs opacity-70 mt-2">{note}</div>
      </div>
    );
  }

  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;

  return children;
}
