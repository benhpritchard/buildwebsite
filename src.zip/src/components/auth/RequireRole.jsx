import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | noauth | forbidden

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setStatus("noauth");
        return;
      }
      const profile = await getTeacherProfile(user.uid);
      const role = profile?.role || "teacher";

      if (allow.includes(role)) setStatus("ok");
      else setStatus("forbidden");
    });

    return () => unsub();
  }, [allow]);

  if (status === "loading") return <div className="pt-32 text-center">Loading...</div>;
  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;
  return children;
}
