import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | noauth | forbidden
  const [debug, setDebug] = useState("");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      try {
        if (!user) {
          setStatus("noauth");
          return;
        }

        // If Firestore fails, we will fall back safely
        let role = "teacher";

        try {
          const profile = await getTeacherProfile(user.uid);
          if (profile?.role) role = profile.role;
        } catch (e) {
          console.error("RequireRole: Firestore read failed:", e);
          setDebug(String(e?.code || e?.message || e));
          // keep role as "teacher" fallback
        }

        if (allow.includes(role)) setStatus("ok");
        else setStatus("forbidden");
      } catch (e) {
        console.error("RequireRole: unexpected error:", e);
        setDebug(String(e?.code || e?.message || e));
        setStatus("forbidden");
      }
    });

    return () => unsub();
  }, [allow]);

  if (status === "loading") {
    return (
      <div className="pt-32 text-center">
        Loading…
        {debug ? <div className="mt-2 text-xs opacity-70">{debug}</div> : null}
      </div>
    );
  }

  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;

  return children;
}
