import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading");
  const [debug, setDebug] = useState("");

  useEffect(() => {
    let done = false;

    const finish = (nextStatus, msg = "") => {
      if (done) return;
      done = true;
      setDebug(msg);
      setStatus(nextStatus);
    };

    const timeout = setTimeout(() => {
      // Firestore blocked — fall back to cached role
      const cachedRole = localStorage.getItem("finnquest_role") || "teacher";
      if (allow.includes(cachedRole)) finish("ok", "Using cached role (Firestore blocked).");
      else finish("forbidden", "Using cached role: not allowed.");
    }, 2500);

    const unsub = onAuthStateChanged(auth, async (user) => {
      try {
        if (!user) {
          clearTimeout(timeout);
          finish("noauth");
          return;
        }

        // Try Firestore quickly
        const profile = await getTeacherProfile(user.uid);
        const role = profile?.role || "teacher";

        // Cache it for next time
        localStorage.setItem("finnquest_role", role);

        clearTimeout(timeout);
        if (allow.includes(role)) finish("ok");
        else finish("forbidden");
      } catch (e) {
        console.error("RequireRole Firestore failed:", e);
        // let the timeout fallback handle it
      }
    });

    return () => {
      clearTimeout(timeout);
      unsub();
    };
  }, [allow]);

  if (status === "loading") {
    return (
      <div className="pt-32 text-center">
        <div className="font-semibold">Loading…</div>
        <div className="text-xs opacity-70 mt-2">{debug || "Checking access…"}</div>
      </div>
    );
  }

  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;

  return children;
}
