import Layout from "./Layout.jsx";

import Home from "./Home";

import ExploreGames from "./ExploreGames";

import Contact from "./Contact";

import About from "./About";

import CPD from "./CPD";

import AdminDashboard from "./AdminDashboard";

import StudentLogin from "./StudentLogin";

import AvatarCreation from "./AvatarCreation";

import StudentDashboard from "./StudentDashboard";

import AdminLogin from "./AdminLogin";

import MainAdminDashboard from "./MainAdminDashboard";

import ViewResources from "./ViewResources";

import TakeQuiz from "./TakeQuiz";

import ClassDashboard from "./ClassDashboard";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    ExploreGames: ExploreGames,
    
    Contact: Contact,
    
    About: About,
    
    CPD: CPD,
    
    AdminDashboard: AdminDashboard,
    
    StudentLogin: StudentLogin,
    
    AvatarCreation: AvatarCreation,
    
    StudentDashboard: StudentDashboard,
    
    AdminLogin: AdminLogin,
    
    MainAdminDashboard: MainAdminDashboard,
    
    ViewResources: ViewResources,
    
    TakeQuiz: TakeQuiz,
    
    ClassDashboard: ClassDashboard,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/ExploreGames" element={<ExploreGames />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/CPD" element={<CPD />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/StudentLogin" element={<StudentLogin />} />
                
                <Route path="/AvatarCreation" element={<AvatarCreation />} />
                
                <Route path="/StudentDashboard" element={<StudentDashboard />} />
                
                <Route path="/AdminLogin" element={<AdminLogin />} />
                
                <Route path="/MainAdminDashboard" element={<MainAdminDashboard />} />
                
                <Route path="/ViewResources" element={<ViewResources />} />
                
                <Route path="/TakeQuiz" element={<TakeQuiz />} />
                
                <Route path="/ClassDashboard" element={<ClassDashboard />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}