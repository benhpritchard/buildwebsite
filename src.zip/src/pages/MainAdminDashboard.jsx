import React, { useEffect, useState } from "react";
import {
  createUserWithEmailAndPassword,
} from "firebase/auth";
import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

import { auth } from "@/lib/firebase";
import { db } from "@/lib/firestore";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

import { Plus, Users, CreditCard, Trash2, LogOut } from "lucide-react";
import Header from "../components/finquest/Header";
import Footer from "../components/finquest/Footer";
import { createPageUrl } from "@/utils";

const MAIN_ADMIN_EMAIL = "benhpritchard2024@gmail.com";

const YEAR_GROUPS = [
  "Year 1","Year 2","Year 3","Year 4","Year 5","Year 6",
  "Year 7","Year 8","Year 9",
];

export default function MainAdminDashboard() {
  const [user, setUser] = useState(null);
  const [teachers, setTeachers] = useState([]);
  const [addOpen, setAddOpen] = useState(false);
  const [newTeacher, setNewTeacher] = useState({
    email: "",
    password: "",
    school_name: "",
    credits_total: 0,
  });

  // 🔐 Verify main admin
  useEffect(() => {
    const stored = localStorage.getItem("finnquest_teacher");
    if (!stored) {
      window.location.href = createPageUrl("AdminLogin");
      return;
    }
    const parsed = JSON.parse(stored);
    if (parsed.email !== MAIN_ADMIN_EMAIL) {
      window.location.href = createPageUrl("AdminDashboard");
      return;
    }
    setUser(parsed);
    loadTeachers();
  }, []);

  const loadTeachers = async () => {
    const snap = await getDocs(collection(db, "teachers"));
    const data = snap.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .filter(t => t.email !== MAIN_ADMIN_EMAIL);
    setTeachers(data);
  };

  // ➕ Create teacher
  const handleAddTeacher = async () => {
    try {
      const { email, password, school_name, credits_total } = newTeacher;

      const cred = await createUserWithEmailAndPassword(
        auth,
        email.trim().toLowerCase(),
        password
      );

      await setDoc(doc(db, "teachers", cred.user.uid), {
        email: email.trim().toLowerCase(),
        role: "teacher",
        school_name,
        credits_total: Number(credits_total),
        credits_used: 0,
        unlocked_years: [],
      });

      setAddOpen(false);
      setNewTeacher({ email: "", password: "", school_name: "", credits_total: 0 });
      loadTeachers();
      alert("Teacher created successfully.");
    } catch (e) {
      console.error(e);
      alert(e.message);
    }
  };

  // 🔓 Toggle year access
  const toggleYear = async (teacher, year) => {
    const current = teacher.unlocked_years || [];
    const updated = current.includes(year)
      ? current.filter(y => y !== year)
      : [...current, year];

    await updateDoc(doc(db, "teachers", teacher.id), {
      unlocked_years: updated,
    });

    loadTeachers();
  };

  // 💳 Update credits
  const updateCredits = async (teacher, credits) => {
    await updateDoc(doc(db, "teachers", teacher.id), {
      credits_total: Number(credits),
    });
    loadTeachers();
  };

  // 🗑 Delete teacher
  const deleteTeacher = async (teacher) => {
    if (!confirm("Delete this teacher?")) return;
    await deleteDoc(doc(db, "teachers", teacher.id));
    loadTeachers();
  };

  const handleLogout = () => {
    localStorage.removeItem("finnquest_teacher");
    window.location.href = createPageUrl("Home");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#FAF7F0]">
      <Header />

      <div className="pt-28 pb-20 px-4 max-w-6xl mx-auto">
        <div className="flex justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#3448C5]">Main Admin Dashboard</h1>
            <p className="text-gray-600">Create teachers, assign credits & year access</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>

        <Button onClick={() => setAddOpen(true)} className="mb-6 bg-[#3448C5]">
          <Plus className="w-4 h-4 mr-2" /> Add Teacher
        </Button>

        <div className="space-y-4">
          {teachers.map(t => (
            <Card key={t.id}>
              <CardContent className="p-6">
                <div className="flex flex-col gap-3">
                  <div>
                    <h3 className="font-semibold">{t.school_name}</h3>
                    <p className="text-sm text-gray-500">{t.email}</p>
                  </div>

                  <div className="flex gap-3">
                    <Badge>Credits: {t.credits_used}/{t.credits_total}</Badge>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    {YEAR_GROUPS.map(y => (
                      <label key={y} className="flex items-center gap-1 text-xs">
                        <Checkbox
                          checked={t.unlocked_years?.includes(y)}
                          onCheckedChange={() => toggleYear(t, y)}
                        />
                        {y}
                      </label>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      type="number"
                      defaultValue={t.credits_total}
                      onBlur={(e) => updateCredits(t, e.target.value)}
                      className="w-32"
                    />
                    <Button variant="outline" onClick={() => deleteTeacher(t)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Teacher</DialogTitle>
          </DialogHeader>

          <div className="space-y-3">
            <Input placeholder="Email" onChange={e => setNewTeacher({ ...newTeacher, email: e.target.value })} />
            <Input placeholder="Temp Password" onChange={e => setNewTeacher({ ...newTeacher, password: e.target.value })} />
            <Input placeholder="School Name" onChange={e => setNewTeacher({ ...newTeacher, school_name: e.target.value })} />
            <Input type="number" placeholder="Credits" onChange={e => setNewTeacher({ ...newTeacher, credits_total: e.target.value })} />
            <Button onClick={handleAddTeacher} className="w-full bg-[#3448C5]">
              Create Teacher
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}
