import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Printer, Pencil, Trash2, UserPlus, LogOut, ArrowLeft, BookOpen, Target, ClipboardCheck } from 'lucide-react';
import Header from '../components/finquest/Header';
import Footer from '../components/finquest/Footer';
import { createPageUrl } from '@/utils';

function generateUsername(name) {
  const cleanName = name.toLowerCase().replace(/[^a-z]/g, '');
  const randomNum = Math.floor(Math.random() * 9000) + 1000;
  return `${cleanName}${randomNum}`;
}

function generatePassword() {
  const adjectives = ['Happy', 'Bright', 'Swift', 'Clever', 'Brave', 'Lucky', 'Sunny', 'Cool'];
  const nouns = ['Star', 'Moon', 'Cloud', 'Tiger', 'Eagle', 'River', 'Mountain', 'Forest'];
  const num = Math.floor(Math.random() * 90) + 10;
  return `${adjectives[Math.floor(Math.random() * adjectives.length)]}${nouns[Math.floor(Math.random() * nouns.length)]}${num}`;
}

export default function ClassDashboard() {
  const queryParams = new URLSearchParams(window.location.search);
  const classId = queryParams.get('classId');
  
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('logins'); // 'logins', 'assessment', 'quiz'
  const [showAddStudents, setShowAddStudents] = useState(false);
  const [newStudentNames, setNewStudentNames] = useState('');
  const [showEditClass, setShowEditClass] = useState(false);
  const [editClassName, setEditClassName] = useState('');
  const [editYearGroup, setEditYearGroup] = useState('');
  
  const queryClient = useQueryClient();

  useEffect(() => {
    const storedTeacher = localStorage.getItem('finnquest_teacher') || localStorage.getItem('finquest_teacher');
    if (!storedTeacher) {
      window.location.href = createPageUrl('AdminLogin');
      return;
    }
    const teacherData = JSON.parse(storedTeacher);
    setUser({ email: teacherData.email, full_name: teacherData.school_name || teacherData.email });
  }, []);

  // Fetch teacher
  const { data: teacher } = useQuery({
    queryKey: ['teacher', user?.email],
    queryFn: async () => {
      const allTeachers = await base44.entities.Teacher.list();
      return allTeachers.find(t => t.email?.toLowerCase() === user?.email?.toLowerCase());
    },
    enabled: !!user?.email,
  });

  // Fetch class details
  const { data: classDetails } = useQuery({
    queryKey: ['class', classId],
    queryFn: async () => {
      const classes = await base44.entities.Class.filter({ id: classId });
      return classes[0];
    },
    enabled: !!classId,
  });

  // Fetch students
  const { data: students = [] } = useQuery({
    queryKey: ['students', classId],
    queryFn: () => base44.entities.Student.filter({ class_id: classId }),
    enabled: !!classId,
  });

  // Mutations
  const createStudentsMutation = useMutation({
    mutationFn: (data) => base44.entities.Student.bulkCreate(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['students'] }),
  });

  const updateTeacherMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Teacher.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['teacher'] }),
  });

  const updateClassMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Class.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['class'] });
      setShowEditClass(false);
    },
  });

  const deleteStudentMutation = useMutation({
    mutationFn: (id) => base44.entities.Student.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      if (teacher) {
        updateTeacherMutation.mutate({
          id: teacher.id,
          data: { credits_used: Math.max(0, (teacher?.credits_used || 1) - 1) }
        });
      }
    },
  });

  const handleAddStudents = async () => {
    if (!newStudentNames.trim() || !classDetails) return;
    
    const names = newStudentNames.split('\n').filter(n => n.trim()).slice(0, 35);
    if (names.length === 0) return;

    const creditsRemaining = (teacher?.credits_total || 0) - (teacher?.credits_used || 0);
    if (names.length > creditsRemaining) {
      alert(`Not enough credits. You have ${creditsRemaining} credits remaining but need ${names.length}.`);
      return;
    }

    const studentsData = names.map(name => ({
      name: name.trim(),
      username: generateUsername(name.trim()),
      password: generatePassword(),
      class_id: classId,
      teacher_id: teacher.id,
      has_created_avatar: false
    }));

    await createStudentsMutation.mutateAsync(studentsData);
    await updateTeacherMutation.mutateAsync({
      id: teacher.id,
      data: { credits_used: (teacher?.credits_used || 0) + names.length }
    });

    setNewStudentNames('');
    setShowAddStudents(false);
  };

  const handleDeleteStudent = async (studentId, studentName) => {
    if (confirm(`Are you sure you want to remove ${studentName}? This will refund 1 credit.`)) {
      deleteStudentMutation.mutate(studentId);
    }
  };

  const handleEditClass = () => {
    if (!editClassName) return;
    updateClassMutation.mutate({
      id: classId,
      data: { name: editClassName, year_group: editYearGroup }
    });
  };

  const openEditClass = () => {
    setEditClassName(classDetails.name);
    setEditYearGroup(classDetails.year_group);
    setShowEditClass(true);
  };

  const handlePrintCards = () => {
    const printContent = document.getElementById('print-cards');
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(`
      <html>
        <head>
          <title>Student Login Cards</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .card-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
            .card { border: 2px solid #3448C5; border-radius: 10px; padding: 15px; text-align: center; page-break-inside: avoid; }
            .card h3 { margin: 0 0 10px 0; color: #3448C5; font-size: 14px; }
            .card p { margin: 5px 0; font-size: 12px; }
            .card .label { color: #666; }
            .card .value { font-weight: bold; color: #333; font-size: 14px; }
            @media print { .card-grid { grid-template-columns: repeat(3, 1fr); } }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  if (!user || !classDetails) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAF7F0' }}>
      <Header />
      
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Button 
              variant="outline" 
              onClick={() => window.location.href = createPageUrl('AdminDashboard')}
              className="mb-4 gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Dashboard
            </Button>
            
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-4xl font-bold" style={{ color: '#3448C5' }}>{classDetails.name}</h1>
                <p className="text-gray-600 mt-2">{classDetails.year_group} • {students.length} Students</p>
              </div>
              <Button onClick={openEditClass} variant="outline" className="gap-2">
                <Pencil className="w-4 h-4" /> Edit Class
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mb-8 border-b border-gray-200 pb-1 overflow-x-auto">
            <button
              onClick={() => setActiveTab('logins')}
              className={`px-6 py-3 font-bold text-lg transition-colors whitespace-nowrap ${
                activeTab === 'logins' 
                  ? 'text-[#3448C5] border-b-4 border-[#3448C5]' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Student Logins
            </button>
            <button
              onClick={() => setActiveTab('assessment')}
              className={`px-6 py-3 font-bold text-lg transition-colors whitespace-nowrap ${
                activeTab === 'assessment' 
                  ? 'text-[#3448C5] border-b-4 border-[#3448C5]' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Assessment
            </button>
            <button
              onClick={() => setActiveTab('quiz')}
              className={`px-6 py-3 font-bold text-lg transition-colors whitespace-nowrap ${
                activeTab === 'quiz' 
                  ? 'text-[#3448C5] border-b-4 border-[#3448C5]' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Set Quiz
            </button>
          </div>

          {/* Content */}
          {activeTab === 'logins' && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
                <CardTitle>Manage Students</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setShowAddStudents(true)} className="gap-1">
                    <UserPlus className="w-4 h-4" /> Add Students
                  </Button>
                  <Button onClick={handlePrintCards} size="sm" className="gap-1 bg-[#3448C5]">
                    <Printer className="w-4 h-4" /> Print Cards
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="border p-3 text-left">Name</th>
                        <th className="border p-3 text-left">Username</th>
                        <th className="border p-3 text-left">Password</th>
                        <th className="border p-3 text-center w-16">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.map((student) => (
                        <tr key={student.id}>
                          <td className="border p-3">{student.name}</td>
                          <td className="border p-3 font-mono">{student.username}</td>
                          <td className="border p-3 font-mono">{student.password}</td>
                          <td className="border p-3 text-center">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteStudent(student.id, student.name)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div id="print-cards" className="hidden">
                  <div className="card-grid">
                    {students.map((student) => (
                      <div key={student.id} className="card">
                        <h3>FinnQuest Login</h3>
                        <p className="label">Name</p>
                        <p className="value">{student.name}</p>
                        <p className="label">Username</p>
                        <p className="value">{student.username}</p>
                        <p className="label">Password</p>
                        <p className="value">{student.password}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'assessment' && (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-200 shadow-sm">
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Target className="w-10 h-10 text-[#3448C5]" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Assessment Area</h2>
              <p className="text-gray-500 max-w-md mx-auto">
                Track student progress, view quiz results, and monitor learning outcomes.
                Coming soon!
              </p>
            </div>
          )}

          {activeTab === 'quiz' && (
            <div className="text-center py-20 bg-white rounded-2xl border border-gray-200 shadow-sm">
              <div className="bg-purple-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <ClipboardCheck className="w-10 h-10 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Set Quiz</h2>
              <p className="text-gray-500 max-w-md mx-auto">
                Create and assign quizzes to your class.
                Coming soon!
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Dialogs */}
      <Dialog open={showAddStudents} onOpenChange={setShowAddStudents}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Students to {classDetails.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium mb-2">Student Names (one per line)</label>
              <Textarea
                value={newStudentNames}
                onChange={(e) => setNewStudentNames(e.target.value)}
                placeholder="John Smith&#10;Jane Doe&#10;..."
                rows={8}
              />
              <p className="text-sm text-gray-500 mt-1">
                {newStudentNames.split('\n').filter(n => n.trim()).length} students • 
                Credits remaining: {(teacher?.credits_total || 0) - (teacher?.credits_used || 0)}
              </p>
            </div>
            <Button onClick={handleAddStudents} className="w-full" style={{ backgroundColor: '#3448C5' }}>
              Add Students
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditClass} onOpenChange={setShowEditClass}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Class</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium mb-2">Class Name</label>
              <Input
                value={editClassName}
                onChange={(e) => setEditClassName(e.target.value)}
                placeholder="e.g., Class 2B"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Year Group</label>
              <Select value={editYearGroup} onValueChange={setEditYearGroup}>
                <SelectTrigger>
                  <SelectValue placeholder="Select year group" />
                </SelectTrigger>
                <SelectContent>
                  {['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Year 5', 'Year 6', 'Year 7', 'Year 8', 'Year 9'].map((year) => (
                    <SelectItem key={year} value={year}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleEditClass} className="w-full" style={{ backgroundColor: '#3448C5' }}>
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
}