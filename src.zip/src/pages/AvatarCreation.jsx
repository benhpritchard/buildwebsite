import React, { useState, useEffect } from 'react';
import { createPageUrl } from '@/utils';
import Header from '../components/finquest/Header';
import Footer from '../components/finquest/Footer';
import FinQuestAvatarOffice from '../components/avatar/FinQuestAvatarOffice';

export default function AvatarCreation() {
  const [student, setStudent] = useState(null);

  useEffect(() => {
    const storedStudent = localStorage.getItem('finnquest_student') || localStorage.getItem('finquest_student');
    if (!storedStudent) {
      window.location.href = createPageUrl('StudentLogin');
      return;
    }
    setStudent(JSON.parse(storedStudent));
  }, []);

  const handleSave = (newState) => {
    // Update local storage with new avatar state
    const updatedStudent = { ...student, avatar_state: newState, has_created_avatar: true };
    localStorage.setItem('finnquest_student', JSON.stringify(updatedStudent));
    setStudent(updatedStudent);
    // Stay on the page - no redirect
  };

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FAF7F0' }}>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#ffd7a0' }}>
      <Header />
      <div className="pt-24 pb-8">
        <FinQuestAvatarOffice student={student} onSave={handleSave} />
      </div>
      <Footer />
    </div>
  );
}