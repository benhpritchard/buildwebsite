import React, { useState } from "react";
import { collection, getDocs, query, where } from "firebase/firestore";

import { db } from "@/lib/firebase";
import { setStudentSession } from "@/lib/studentSession";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "../components/finquest/Header";
import Footer from "../components/finquest/Footer";
import { createPageUrl } from "@/utils";

function withTimeout(promise, ms = 8000, label = "Operation") {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms)
    ),
  ]);
}

export default function StudentLogin() {
  const [classCode, setClassCode] = useState("");
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");

  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setError("");
    setIsLoading(true);

    const code = classCode.trim().toUpperCase();
    const uname = username.trim().toLowerCase();
    const pass = pin.trim();

    if (!code || !uname || !pass) {
      setError("Please enter class code, username and PIN.");
      setIsLoading(false);
      return;
    }

    try {
      // 1) Find class by classCode
      const classQ = query(collection(db, "classes"), where("classCode", "==", code));
      const classSnap = await withTimeout(getDocs(classQ), 8000, "Load class");

      if (classSnap.empty) {
        setError("Class code not found.");
        setIsLoading(false);
        return;
      }

      const clsDoc = classSnap.docs[0];
      const cls = { id: clsDoc.id, ...clsDoc.data() };

      // 2) Find student in that class by username
      const studentQ = query(
        collection(db, "students"),
        where("classId", "==", cls.id),
        where("username", "==", uname)
      );

      const studentSnap = await withTimeout(getDocs(studentQ), 8000, "Load student");

      if (studentSnap.empty) {
        setError("Username not found for this class.");
        setIsLoading(false);
        return;
      }

      const sDoc = studentSnap.docs[0];
      const student = { id: sDoc.id, ...sDoc.data() };

      // 3) Check PIN (we store it as "pin" in Firestore)
      if (String(student.pin || "") !== pass) {
        setError("Incorrect PIN.");
        setIsLoading(false);
        return;
      }

      // 4) Store session
      setStudentSession({
        ...student,
        class_id: cls.id,         // backwards friendly
        teacher_id: cls.teacherId // backwards friendly
      });

      // 5) Route
      if (student.has_created_avatar) {
        window.location.href = createPageUrl("StudentDashboard");
      } else {
        window.location.href = createPageUrl("AvatarCreation");
      }
    } catch (e) {
      console.error("Student login failed:", e);
      setError(e?.message?.includes("timed out")
        ? "Login timed out. This is usually school Wi-Fi blocking Firestore. Try a hotspot once to confirm."
        : "Login failed. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#FAF7F0" }}>
      <Header />

      <div className="pt-32 pb-20 min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6922e5b0ed36c6ebd97761f8/8a8ccc245_Gemini_Generated_Image_3z9ysf3z9ysf3z9y.png"
                alt="FinnQuest Logo"
                className="h-20 w-auto mx-auto rounded-full"
              />
            </div>
            <CardTitle className="text-2xl" style={{ color: "#3448C5" }}>
              Student Login
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Enter your class code + login details
            </p>
          </CardHeader>

          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Class Code</label>
                <Input
                  value={classCode}
                  onChange={(e) => setClassCode(e.target.value)}
                  placeholder="e.g. ABCD12"
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Username</label>
                <Input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. aisha4821"
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">PIN</label>
                <Input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="4 digits"
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>

              {error && <p className="text-red-500 text-sm text-center">{error}</p>}

              <Button
                onClick={handleLogin}
                className="w-full text-lg py-6"
                style={{ backgroundColor: "#3448C5" }}
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
