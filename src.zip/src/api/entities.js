import { base44 } from './base44Client';


export const CPDEvent = base44.entities.CPDEvent;

export const Teacher = base44.entities.Teacher;

export const Class = base44.entities.Class;

export const Student = base44.entities.Student;



// auth sdk:
export const User = base44.auth;