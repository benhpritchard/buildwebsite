import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

export default function RequireRole({ allow = [], children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | noauth | forbidden | error
  const [debug, setDebug] = useState("");

  useEffect(() => {
    let timedOut = false;

    const timer = setTimeout(() => {
      timedOut = true;
      setDebug("AUTH GATE TIMEOUT (Firestore/Network delay)");
      setStatus("error");
    }, 6000);

    const unsub = onAuthStateChanged(auth, async (user) => {
      try {
        if (timedOut) return;

        if (!user) {
          clearTimeout(timer);
          setStatus("noauth");
          return;
        }

        const profile = await getTeacherProfile(user.uid);
        const role = profile?.role || "teacher";

        clearTimeout(timer);

        if (allow.includes(role)) setStatus("ok");
        else setStatus("forbidden");
      } catch (e) {
        console.error("RequireRole error:", e);
        clearTimeout(timer);
        setDebug(String(e?.code || e?.message || e));
        setStatus("error");
      }
    });

    return () => {
      clearTimeout(timer);
      unsub();
    };
  }, [allow]);

  if (status === "loading") {
    return (
      <div className="pt-32 text-center">
        <div className="font-semibold">AUTH GATE: Loading…</div>
        <div className="text-xs opacity-70 mt-2">Checking login + role…</div>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="pt-32 text-center">
        <div className="font-semibold text-red-600">AUTH GATE ERROR</div>
        <div className="text-xs opacity-70 mt-2">{debug}</div>
        <div className="text-xs opacity-70 mt-2">
          If you see this, Firestore still isn’t reachable from this network.
        </div>
      </div>
    );
  }

  if (status === "noauth") return <Navigate to="/login" replace />;
  if (status === "forbidden") return <Navigate to="/" replace />;

  return children;
}
