import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword } from "firebase/auth";

import { auth } from "@/lib/firebase";
import { getTeacherProfile } from "@/lib/roles";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "../components/finquest/Header";
import Footer from "../components/finquest/Footer";

export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setError("");
    setIsLoading(true);

    try {
      const cred = await signInWithEmailAndPassword(
        auth,
        email.trim().toLowerCase(),
        password
      );

      const uid = cred.user.uid;

      // default role if Firestore blocked
      let role = "teacher";

      try {
        const profile = await getTeacherProfile(uid);
        role = profile?.role || "teacher";
      } catch (e) {
        console.error("Firestore role lookup failed:", e);
        setError(
          "Logged in, but this network blocks the database (Firestore).\n" +
            "You can still use the site, but main admin features may be limited here."
        );
      }

      // Cache role so the app can work without Firestore reads
      localStorage.setItem("finnquest_role", role);
      localStorage.setItem("finnquest_uid", uid);
      localStorage.setItem("finnquest_email", cred.user.email || "");

      if (role === "main_admin") navigate("/MainAdminDashboard");
      else navigate("/AdminDashboard");
    } catch (e) {
      console.error("Firebase login error:", e);
      setError(`Login failed: ${e?.code || e?.message || "unknown"}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#FAF7F0" }}>
      <Header />
      <div className="pt-32 pb-20 min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl" style={{ color: "#3448C5" }}>
              Teacher Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Password</label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>

              {error && (
                <p className="text-red-600 text-sm text-center whitespace-pre-wrap">
                  {error}
                </p>
              )}

              <Button
                onClick={handleLogin}
                className="w-full text-lg py-6"
                style={{ backgroundColor: "#3448C5" }}
                disabled={isLoading || !email.trim() || !password}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
